package com.example.floatinggemini

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

class CropOverlayView(
    context: Context,
    private val screenshot: Bitmap,
    private val onCropped: (Bitmap) -> Unit,
    private val onCancelled: () -> Unit
) : View(context) {

    private val paintBorder = Paint().apply {
        color = Color.parseColor("#00BFFF")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val paintBg = Paint().apply {
        color = Color.parseColor("#80000000")
    }
    private val paintCorner = Paint().apply {
        color = Color.parseColor("#00BFFF")
        style = Paint.Style.FILL
    }

    private var cropRect = RectF(150f, 300f, 800f, 900f)
    private val cornerSize = 40f
    private var mode = 0 // 0: None, 1: Move, 2: TL, 3: TR, 4: BL, 5: BR
    private var lastX = 0f
    private var lastY = 0f

    private val btnConfirm = RectF()
    private val btnCancel = RectF()

    init {
        val dm = context.resources.displayMetrics
        val screenW = dm.widthPixels.toFloat()
        val screenH = dm.heightPixels.toFloat()

        btnCancel.set(screenW / 2 - 140f, screenH - 220f, screenW / 2 - 40f, screenH - 140f)
        btnConfirm.set(screenW / 2 + 40f, screenH - 220f, screenW / 2 + 140f, screenH - 140f)

        // Sesuaikan cropRect awal biar proporsional
        cropRect.set(screenW * 0.15f, screenH * 0.25f, screenW * 0.85f, screenH * 0.65f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // 1. Background screenshot
        canvas.drawBitmap(screenshot, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), null)

        // 2. Overlay gelap
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintBg)

        // 3. Hapus area crop pakai PorterDuff CLEAR
        val clearPaint = Paint().apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        canvas.drawRect(cropRect, clearPaint)

        // 4. Border area crop
        canvas.drawRect(cropRect, paintBorder)

        // 5. 4 sudut handle
        canvas.drawRect(cropRect.left, cropRect.top,
            cropRect.left + cornerSize, cropRect.top + cornerSize, paintCorner)
        canvas.drawRect(cropRect.right - cornerSize, cropRect.top,
            cropRect.right, cropRect.top + cornerSize, paintCorner)
        canvas.drawRect(cropRect.left, cropRect.bottom - cornerSize,
            cropRect.left + cornerSize, cropRect.bottom, paintCorner)
        canvas.drawRect(cropRect.right - cornerSize, cropRect.bottom - cornerSize,
            cropRect.right, cropRect.bottom, paintCorner)

        // 6. Tombol Batal (X) & Konfirmasi (✓)
        val txtPaint = Paint().apply {
            color = Color.WHITE
            textSize = 60f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        canvas.drawRoundRect(btnCancel, 20f, 20f,
            Paint().apply { color = Color.parseColor("#F44336") })
        canvas.drawText("X", btnCancel.centerX(), btnCancel.centerY() + 20f, txtPaint)

        canvas.drawRoundRect(btnConfirm, 20f, 20f,
            Paint().apply { color = Color.parseColor("#4CAF50") })
        canvas.drawText("✓", btnConfirm.centerX(), btnConfirm.centerY() + 20f, txtPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = x; lastY = y
                mode = when {
                    btnCancel.contains(x, y) -> {
                        onCancelled()
                        return true
                    }
                    btnConfirm.contains(x, y) -> {
                        cropBitmap()
                        return true
                    }
                    isNear(cropRect.left, cropRect.top, x, y) -> 2
                    isNear(cropRect.right, cropRect.top, x, y) -> 3
                    isNear(cropRect.left, cropRect.bottom, x, y) -> 4
                    isNear(cropRect.right, cropRect.bottom, x, y) -> 5
                    cropRect.contains(x, y) -> 1
                    else -> 0
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = x - lastX
                val dy = y - lastY
                when (mode) {
                    1 -> cropRect.offset(dx, dy)
                    2 -> { cropRect.left += dx; cropRect.top += dy }
                    3 -> { cropRect.right += dx; cropRect.top += dy }
                    4 -> { cropRect.left += dx; cropRect.bottom += dy }
                    5 -> { cropRect.right += dx; cropRect.bottom += dy }
                }
                // Batasi di area layar
                cropRect.left = cropRect.left.coerceIn(0f, width.toFloat())
                cropRect.top = cropRect.top.coerceIn(0f, height.toFloat())
                cropRect.right = cropRect.right.coerceIn(0f, width.toFloat())
                cropRect.bottom = cropRect.bottom.coerceIn(0f, height.toFloat())

                if (cropRect.width() > 100 && cropRect.height() > 100) {
                    lastX = x; lastY = y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                mode = 0
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun isNear(rectX: Float, rectY: Float, tx: Float, ty: Float): Boolean {
        return abs(tx - rectX) < 80f && abs(ty - rectY) < 80f
    }

    private fun cropBitmap() {
        val scaleX = screenshot.width.toFloat() / width.toFloat()
        val scaleY = screenshot.height.toFloat() / height.toFloat()

        val cropX = (cropRect.left * scaleX).toInt().coerceIn(0, screenshot.width - 1)
        val cropY = (cropRect.top * scaleY).toInt().coerceIn(0, screenshot.height - 1)
        val cropW = (cropRect.width() * scaleX).toInt()
            .coerceAtMost(screenshot.width - cropX)
        val cropH = (cropRect.height() * scaleY).toInt()
            .coerceAtMost(screenshot.height - cropY)

        if (cropW > 0 && cropH > 0) {
            val cropped = Bitmap.createBitmap(screenshot, cropX, cropY, cropW, cropH)
            onCropped(cropped)
        }
    }
}