package com.example.floatinggemini

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

class CropOverlayView(
    context: Context,
    private val screenshot: Bitmap,
    private val onCropped: (Bitmap) -> Unit,
    private val onCancelled: () -> Unit
) : View(context) {

    private val paintBorder = Paint().apply {
        color = Color.parseColor("#00BFFF")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val paintBg = Paint().apply {
        color = Color.parseColor("#80000000")
    }
    private val paintCorner = Paint().apply {
        color = Color.parseColor("#00BFFF")
        style = Paint.Style.FILL
    }

    private var cropRect = RectF(150f, 300f, 800f, 900f)
    private val cornerSize = 45f
    private var mode = 0
    private var lastX = 0f
    private var lastY = 0f

    // 🔥 Tombol di BAWAH, ukuran kecil (kaya sebelumnya)
    private val btnConfirm = RectF()
    private val btnCancel = RectF()
    private var btnAreaTop = 0f

    init {
        val dm = context.resources.displayMetrics
        val screenW = dm.widthPixels.toFloat()
        val screenH = dm.heightPixels.toFloat()

        // Tombol kecil di bawah tengah
        val btnSize = 130f
        val gap = 40f
        btnCancel.set(
            screenW / 2 - btnSize - gap / 2, screenH - 230f,
            screenW / 2 - gap / 2, screenH - 100f
        )
        btnConfirm.set(
            screenW / 2 + gap / 2, screenH - 230f,
            screenW / 2 + btnSize + gap / 2, screenH - 100f
        )
        btnAreaTop = screenH - 260f

        // Crop box awal
        cropRect.set(
            screenW * 0.15f, screenH * 0.2f,
            screenW * 0.85f, screenH * 0.6f
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawBitmap(screenshot, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), null)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintBg)

        val clearPaint = Paint().apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        canvas.drawRect(cropRect, clearPaint)
        canvas.drawRect(cropRect, paintBorder)

        // 4 sudut
        canvas.drawRect(cropRect.left, cropRect.top,
            cropRect.left + cornerSize, cropRect.top + cornerSize, paintCorner)
        canvas.drawRect(cropRect.right - cornerSize, cropRect.top,
            cropRect.right, cropRect.top + cornerSize, paintCorner)
        canvas.drawRect(cropRect.left, cropRect.bottom - cornerSize,
            cropRect.left + cornerSize, cropRect.bottom, paintCorner)
        canvas.drawRect(cropRect.right - cornerSize, cropRect.bottom - cornerSize,
            cropRect.right, cropRect.bottom, paintCorner)

        // 🔥 Tombol
        val txtPaint = Paint().apply {
            color = Color.WHITE
            textSize = 55f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        canvas.drawRoundRect(btnCancel, 20f, 20f,
            Paint().apply { color = Color.parseColor("#F44336") })
        canvas.drawText("✕", btnCancel.centerX(), btnCancel.centerY() + 20f, txtPaint)

        canvas.drawRoundRect(btnConfirm, 20f, 20f,
            Paint().apply { color = Color.parseColor("#4CAF50") })
        canvas.drawText("✓", btnConfirm.centerX(), btnConfirm.centerY() + 20f, txtPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = x; lastY = y

                // 🔥 CEK TOMBOL DULUAN (prioritas tertinggi)
                if (btnCancel.contains(x, y)) {
                    onCancelled()
                    return true
                }
                if (btnConfirm.contains(x, y)) {
                    cropBitmap()
                    return true
                }

                // Baru cek crop box
                mode = when {
                    isNear(cropRect.left, cropRect.top, x, y) -> 2
                    isNear(cropRect.right, cropRect.top, x, y) -> 3
                    isNear(cropRect.left, cropRect.bottom, x, y) -> 4
                    isNear(cropRect.right, cropRect.bottom, x, y) -> 5
                    cropRect.contains(x, y) -> 1
                    else -> 0
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = x - lastX
                val dy = y - lastY
                when (mode) {
                    1 -> cropRect.offset(dx, dy)
                    2 -> { cropRect.left += dx; cropRect.top += dy }
                    3 -> { cropRect.right += dx; cropRect.top += dy }
                    4 -> { cropRect.left += dx; cropRect.bottom += dy }
                    5 -> { cropRect.right += dx; cropRect.bottom += dy }
                }

                // Batasi biar nggak masuk area tombol
                cropRect.left = cropRect.left.coerceIn(0f, width.toFloat())
                cropRect.right = cropRect.right.coerceIn(0f, width.toFloat())
                cropRect.top = cropRect.top.coerceIn(0f, height.toFloat())
                cropRect.bottom = cropRect.bottom.coerceIn(0f, btnAreaTop)

                if (cropRect.width() > 100 && cropRect.height() > 100) {
                    lastX = x; lastY = y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                mode = 0
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun isNear(rectX: Float, rectY: Float, tx: Float, ty: Float): Boolean {
        return abs(tx - rectX) < 80f && abs(ty - rectY) < 80f
    }

    private fun cropBitmap() {
        val scaleX = screenshot.width.toFloat() / width.toFloat()
        val scaleY = screenshot.height.toFloat() / height.toFloat()

        val cropX = (cropRect.left * scaleX).toInt().coerceIn(0, screenshot.width - 1)
        val cropY = (cropRect.top * scaleY).toInt().coerceIn(0, screenshot.height - 1)
        val cropW = (cropRect.width() * scaleX).toInt()
            .coerceAtMost(screenshot.width - cropX)
        val cropH = (cropRect.height() * scaleY).toInt()
            .coerceAtMost(screenshot.height - cropY)

        if (cropW > 0 && cropH > 0) {
            val cropped = Bitmap.createBitmap(screenshot, cropX, cropY, cropW, cropH)
            onCropped(cropped)
        }
    }
}