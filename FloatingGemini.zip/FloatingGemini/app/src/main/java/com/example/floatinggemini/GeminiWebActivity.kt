package com.example.floatinggemini

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class GeminiWebActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var tvStatus: TextView
    private var cropFile: File? = null
    private var autoPrompt = false
    private var injectedOnce = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gemini_web)

        webView = findViewById(R.id.webView)
        tvStatus = findViewById(R.id.tvStatus)

        // Path file crop dari intent
        val cropPath = intent.getStringExtra("crop_path")
        if (cropPath != null) {
            cropFile = File(cropPath)
        }

        // Baca mode dari SharedPreferences
        autoPrompt = getSharedPreferences("floating_pref", MODE_PRIVATE)
            .getBoolean("auto_prompt", false)

        // Setup WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
        }

        // Cookie (biar login Google tetep keinget)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        // 🔥 INTERCEPT FILE PICKER — auto-load gambar crop
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // Kalo ada gambar crop, langsung kasih ke Gemini
                if (cropFile != null && cropFile!!.exists()) {
                    val uri = FileProvider.getUriForFile(
                        this@GeminiWebActivity,
                        "$packageName.fileprovider",
                        cropFile!!
                    )
                    filePathCallback?.onReceiveValue(arrayOf(uri))
                    tvStatus.text = "Gambar keisi! Tap kirim ▶"
                    return true
                }
                return false
            }
        }

        // Inject JS setelah halaman selesai load
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                tvStatus.text = "Gemini siap — tap 📎 untuk kirim gambar"

                // Auto-isi prompt kalo mode auto & belum pernah di-inject
                if (autoPrompt && !injectedOnce) {
                    injectedOnce = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        injectPrompt()
                    }, 1500)
                }
            }
        }

        // Load Gemini
        webView.loadUrl("https://gemini.google.com/app")

        // Tombol Tutup
        findViewById<Button>(R.id.btnClose).setOnClickListener {
            finish()
        }
    }

    // 🔥 JS Injection: auto-isi prompt "Jawab atau kerjakan soal ini"
    private fun injectPrompt() {
        val js = """
            (function() {
                try {
                    var textarea = document.querySelector('textarea');
                    if (!textarea) textarea = document.querySelector('[contenteditable="true"]');
                    if (textarea) {
                        textarea.focus();
                        textarea.value = 'Jawab atau kerjakan soal ini';
                        textarea.dispatchEvent(new Event('input', { bubbles: true }));
                        console.log('Prompt diisi otomatis');
                    }
                } catch(e) {
                    console.log('Inject error: ' + e);
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}