package com.example.floatinggemini

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class GeminiWebActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var tvStatus: TextView
    private lateinit var headerBar: LinearLayout
    private lateinit var bottomHandle: View
    private lateinit var resizeHandle: View

    private var cropFile: File? = null
    private var autoPrompt = false
    private var injectedOnce = false
    private var lastW = 0
    private var lastH = 0

    private lateinit var prefs: SharedPreferences

    companion object {
        private const val PREF_NAME = "gemini_web_pref"
        private const val KEY_WIDTH = "window_width"
        private const val KEY_HEIGHT = "window_height"
        private const val MIN_W = 500
        private const val MIN_H = 700
        private const val SWIPE_UP_THRESHOLD = 120f

        // 🔥 Simpen instance biar state WebView nggak ilang
        var instance: GeminiWebActivity? = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gemini_web)

        instance = this
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE)

        webView = findViewById(R.id.webView)
        tvStatus = findViewById(R.id.tvStatus)
        headerBar = findViewById(R.id.headerBar)
        bottomHandle = findViewById(R.id.bottomHandle)
        resizeHandle = findViewById(R.id.resizeHandle)

        // 🔥 BACKGROUND TRANSPARAN (biar nggak item)
        window?.setBackgroundDrawableResource(android.R.color.transparent)

        // Restore ukuran window
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        lastW = prefs.getInt(KEY_WIDTH, (screenW * 0.92).toInt())
        lastH = prefs.getInt(KEY_HEIGHT, (screenH * 0.80).toInt())
        window?.setLayout(lastW, lastH)
        setFinishOnTouchOutside(false)

        // Path crop
        val cropPath = intent.getStringExtra("crop_path")
        if (cropPath != null) cropFile = File(cropPath)

        autoPrompt = getSharedPreferences("floating_pref", MODE_PRIVATE)
            .getBoolean("auto_prompt", false)

        // Setup WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (cropFile != null && cropFile!!.exists()) {
                    try {
                        val uri = FileProvider.getUriForFile(
                            this@GeminiWebActivity,
                            "$packageName.fileprovider",
                            cropFile!!
                        )
                        filePathCallback?.onReceiveValue(arrayOf(uri))
                        tvStatus.text = "✅ Gambar keisi! Tap kirim ▶"
                    } catch (e: Exception) {
                        Log.e("GeminiWeb", "FileProvider error: ${e.message}")
                        filePathCallback?.onReceiveValue(null)
                    }
                    return true
                }
                return false
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                tvStatus.text = "Tap 📎 di Gemini untuk kirim gambar"

                if (autoPrompt && !injectedOnce) {
                    injectedOnce = true
                    Handler(Looper.getMainLooper()).postDelayed({ injectPrompt() }, 1500)
                }
            }
        }

        // Load Gemini cuma kalau WebView belum pernah load
        if (webView.url == null) {
            webView.loadUrl("https://gemini.google.com/app")
        }

        findViewById<Button>(R.id.btnClose).setOnClickListener {
            saveSize()
            hideMiniBubble()
            finish()
            instance = null
        }

        // 🔥 Minimize = sembunyiin window, munculin bubble kecil
        findViewById<Button>(R.id.btnMinimize).setOnClickListener {
            saveSize()
            showMiniBubble()
            // 🔥 Cuma hide, jangan finish (biar state terjaga)
            moveTaskToBack(true)
        }

        setupDrag()
        setupResize()
        setupBottomSwipe()
    }

    // 🔥 Handle crop baru saat activity masih hidup
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        val newCropPath = intent.getStringExtra("crop_path")
        if (newCropPath != null) {
            cropFile = File(newCropPath)
            tvStatus.text = "Gambar baru siap — tap 📎 untuk kirim"
        }
    }

    private fun showMiniBubble() {
        val svcIntent = Intent(this, FloatingService::class.java).apply {
            action = "SHOW_MIN_BUBBLE"
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(svcIntent)
        } else {
            startService(svcIntent)
        }
    }

    private fun hideMiniBubble() {
        val svcIntent = Intent(this, FloatingService::class.java).apply {
            action = "HIDE_MIN_BUBBLE"
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(svcIntent)
        } else {
            startService(svcIntent)
        }
    }

    private fun setupDrag() {
        headerBar.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = window?.attributes ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        window?.attributes = params
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun setupResize() {
        resizeHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startW = 0
            private var startH = 0
            private var startX = 0f
            private var startY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        val params = window?.attributes ?: return false
                        startW = params.width
                        startH = params.height
                        startX = event.rawX
                        startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lastW = (startW + (event.rawX - startX)).toInt().coerceAtLeast(MIN_W)
                        lastH = (startH + (event.rawY - startY)).toInt().coerceAtLeast(MIN_H)
                        window?.setLayout(lastW, lastH)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSize()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun setupBottomSwipe() {
        bottomHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = event.rawY - startY
                        if (dy < -SWIPE_UP_THRESHOLD) {
                            saveSize()
                            hideMiniBubble()
                            finish()
                            instance = null
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun saveSize() {
        prefs.edit()
            .putInt(KEY_WIDTH, lastW)
            .putInt(KEY_HEIGHT, lastH)
            .apply()
    }

    private fun injectPrompt() {
        val js = """
            (function() {
                try {
                    var prompt = 'Jawab atau kerjakan soal ini';
                    var selectors = [
                        'rich-textarea [contenteditable="true"]',
                        '.ql-editor',
                        'div[contenteditable="true"]',
                        'textarea'
                    ];
                    var editor = null;
                    for (var i = 0; i < selectors.length; i++) {
                        editor = document.querySelector(selectors[i]);
                        if (editor) break;
                    }
                    if (!editor) return 'notfound';
                    
                    var currentText = editor.innerText || editor.value || '';
                    if (currentText.indexOf('Jawab atau kerjakan') !== -1) {
                        return 'already';
                    }
                    
                    editor.focus();
                    editor.click();
                    
                    try {
                        document.execCommand('insertText', false, prompt);
                        return 'ok-exec';
                    } catch(e) {}
                    
                    if (editor.value !== undefined) {
                        editor.value = prompt;
                        editor.dispatchEvent(new Event('input', { bubbles: true }));
                        return 'ok-value';
                    }
                    
                    editor.innerText = prompt;
                    editor.dispatchEvent(new Event('input', { bubbles: true }));
                    editor.dispatchEvent(new Event('change', { bubbles: true }));
                    return 'ok-inner';
                } catch(e) {
                    return 'error: ' + e.message;
                }
            })();
        """.trimIndent()

        webView.evaluateJavascript(js) { result ->
            Log.d("GeminiInject", "Result: $result")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            saveSize()
            hideMiniBubble()
            @Suppress("DEPRECATION")
            super.onBackPressed()
            instance = null
        }
    }

    override fun onPause() {
        super.onPause()
        saveSize()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }
}