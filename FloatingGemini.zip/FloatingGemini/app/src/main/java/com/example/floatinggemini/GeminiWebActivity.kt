package com.example.floatinggemini

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class GeminiWebActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var tvStatus: TextView
    private lateinit var headerBar: LinearLayout
    private var cropFile: File? = null
    private var autoPrompt = false
    private var injectedOnce = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gemini_web)

        webView = findViewById(R.id.webView)
        tvStatus = findViewById(R.id.tvStatus)
        headerBar = findViewById(R.id.headerBar)

        // Ukuran window: 92% lebar, 80% tinggi layar
        window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            (resources.displayMetrics.heightPixels * 0.80).toInt()
        )
        // Biar nggak ketutup kalau tap di luar (opsional)
        setFinishOnTouchOutside(false)

        // Ambil path crop
        val cropPath = intent.getStringExtra("crop_path")
        if (cropPath != null) {
            cropFile = File(cropPath)
        }

        // Baca mode
        autoPrompt = getSharedPreferences("floating_pref", MODE_PRIVATE)
            .getBoolean("auto_prompt", false)

        // Setup WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        // 🔥 Intercept file picker
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (cropFile != null && cropFile!!.exists()) {
                    try {
                        val uri = FileProvider.getUriForFile(
                            this@GeminiWebActivity,
                            "$packageName.fileprovider",
                            cropFile!!
                        )
                        filePathCallback?.onReceiveValue(arrayOf(uri))
                        tvStatus.text = "✅ Gambar keisi! Tap tombol kirim ▶"
                    } catch (e: Exception) {
                        Log.e("GeminiWeb", "FileProvider error: ${e.message}")
                        filePathCallback?.onReceiveValue(null)
                    }
                    return true
                }
                return false
            }
        }

        // Client
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                tvStatus.text = "Tap 📎 di Gemini untuk kirim gambar"

                if (autoPrompt && !injectedOnce) {
                    injectedOnce = true
                    // Coba inject 3x biar pasti kena
                    Handler(Looper.getMainLooper()).postDelayed({ injectPrompt() }, 1200)
                    Handler(Looper.getMainLooper()).postDelayed({ injectPrompt() }, 2500)
                    Handler(Looper.getMainLooper()).postDelayed({ injectPrompt() }, 4000)
                }
            }
        }

        webView.loadUrl("https://gemini.google.com/app")

        findViewById<Button>(R.id.btnClose).setOnClickListener {
            finish()
        }

        setupDrag()
    }

    // 🔥 Drag window via headerBar
    private fun setupDrag() {
        headerBar.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = window?.attributes ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        window?.attributes = params
                        return true
                    }
                }
                return false
            }
        })
    }

    // 🔥 Auto-isi prompt "Jawab atau kerjakan soal ini"
    private fun injectPrompt() {
        val js = """
            (function() {
                try {
                    var prompt = 'Jawab atau kerjakan soal ini';
                    
                    var selectors = [
                        'rich-textarea [contenteditable="true"]',
                        '.ql-editor',
                        'div[contenteditable="true"]',
                        'textarea'
                    ];
                    
                    var editor = null;
                    for (var i = 0; i < selectors.length; i++) {
                        editor = document.querySelector(selectors[i]);
                        if (editor) { break; }
                    }
                    
                    if (!editor) { return 'notfound'; }
                    
                    editor.focus();
                    editor.click();
                    
                    try {
                        document.execCommand('insertText', false, prompt);
                        return 'ok-exec';
                    } catch(e) {}
                    
                    if (editor.value !== undefined) {
                        editor.value = prompt;
                        editor.dispatchEvent(new Event('input', { bubbles: true }));
                        return 'ok-value';
                    }
                    
                    editor.innerText = prompt;
                    editor.dispatchEvent(new Event('input', { bubbles: true }));
                    editor.dispatchEvent(new Event('change', { bubbles: true }));
                    return 'ok-inner';
                    
                } catch(e) {
                    return 'error: ' + e.message;
                }
            })();
        """.trimIndent()

        webView.evaluateJavascript(js) { result ->
            Log.d("GeminiInject", "Result: $result")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}