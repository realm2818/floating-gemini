package com.example.floatinggemini

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: SharedPreferences
    private var mediaProjection: MediaProjection? = null
    private var cropView: CropOverlayView? = null
    private var bubbleView: View? = null
    private var expandedBubbleView: View? = null
    private var overlayView: View? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var currentImageReader: ImageReader? = null
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("floating_pref", MODE_PRIVATE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::windowManager.isInitialized) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }

        when (intent?.action) {
            "HIDE_MIN_BUBBLE" -> {
                // Cuma sembunyiin bubble utama (nggak ada mini bubble lagi)
                bubbleView?.visibility = View.GONE
                return START_STICKY
            }
        }

        // Kalo service udah jalan, tinggal munculin bubble
        if (bubbleView != null && bubbleView!!.isAttachedToWindow) {
            bubbleView?.visibility = View.VISIBLE
            return START_NOT_STICKY
        }

        startForegroundNotification()

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra("data")
        }

        if (data == null) {
            try { showBubble() } catch (e: Exception) {
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
            }
            return START_STICKY
        }

        try {
            val projectionManager =
                getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    try {
                        virtualDisplay?.release()
                        currentImageReader?.close()
                    } catch (_: Exception) {}
                }
            }, Handler(Looper.getMainLooper()))

            val metrics = DisplayMetrics()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = windowManager.currentWindowMetrics.bounds
                screenWidth = bounds.width()
                screenHeight = bounds.height()
                screenDensity = resources.configuration.densityDpi
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(metrics)
                screenWidth = metrics.widthPixels
                screenHeight = metrics.heightPixels
                screenDensity = metrics.densityDpi
            }

            currentImageReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            )

            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "ScreenCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                currentImageReader!!.surface, null, null
            )

            showBubble()
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
            stopSelf()
        }

        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "floating_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Floating Service",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Floating Gemini Aktif")
            .setContentText("Tap bubble = opsi, long-press = stop")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                1, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, notif)
        }
    }

    // ============================
    // BUBBLE UTAMA
    // ============================
    private fun showBubble() {
        if (!::windowManager.isInitialized) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }

        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.layout_bubble, null)

        // Ambil setting size & opacity
        val sizeDp = prefs.getInt("bubble_size", 60)
        val opacityPercent = prefs.getInt("bubble_opacity", 100)
        val sizePx = (sizeDp * resources.displayMetrics.density).toInt()

        val params = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        bubbleView?.alpha = opacityPercent / 100f

        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var isDragging = false
            private var downTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        isDragging = false
                        downTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(bubbleView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val holdDuration = System.currentTimeMillis() - downTime
                        if (!isDragging) {
                            if (holdDuration > 800) {
                                // Long press = stop
                                Toast.makeText(
                                    this@FloatingService,
                                    "Floating Gemini dihentikan",
                                    Toast.LENGTH_SHORT
                                ).show()
                                stopSelf()
                            } else {
                                // Tap = expand (muncul 2 tombol)
                                expandBubble(params.x, params.y)
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(bubbleView, params)
    }

    // ============================
    // BUBBLE MEKAR (2 tombol: Scan & Web)
    // ============================
    private fun expandBubble(bubbleX: Int, bubbleY: Int) {
        if (isExpanded) return
        isExpanded = true

        // Sembunyiin bubble utama
        bubbleView?.visibility = View.GONE

        // Overlay semi-transparan buat nangkep tap di luar
        overlayView = View(this).apply {
            setBackgroundColor(0x33000000.toInt())
            isClickable = true
            setOnClickListener {
                collapseBubble()
            }
        }
        val overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(overlayView, overlayParams)

        // Expanded bubble (2 tombol)
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        expandedBubbleView = inflater.inflate(R.layout.layout_bubble_expanded, null)

        val expandParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleX
            y = bubbleY
        }
        windowManager.addView(expandedBubbleView, expandParams)

        // Tombol Scan
        expandedBubbleView?.findViewById<TextView>(R.id.btnScanBubble)?.setOnClickListener {
            collapseBubble()
            Handler(Looper.getMainLooper()).postDelayed({
                captureScreen()
            }, 200)
        }

        // Tombol Web
        expandedBubbleView?.findViewById<TextView>(R.id.btnWebBubble)?.setOnClickListener {
            collapseBubble()
            openGeminiWindow()
        }
    }

    private fun collapseBubble() {
        if (!isExpanded) return
        isExpanded = false

        expandedBubbleView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        expandedBubbleView = null

        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null

        bubbleView?.visibility = View.VISIBLE
    }

    // ============================
    // BUKA GEMINI WEB
    // ============================
    private fun openGeminiWindow() {
        try {
            val intent = Intent(this, GeminiWebActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka Gemini: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ============================
    // SCREENSHOT & CROP
    // ============================
    private fun captureScreen() {
        try {
            if (virtualDisplay == null) {
                bubbleView?.visibility = View.VISIBLE
                return
            }

            try {
                currentImageReader?.setOnImageAvailableListener(null, null)
                currentImageReader?.close()
            } catch (_: Exception) {}

            val newReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            )
            currentImageReader = newReader
            virtualDisplay?.setSurface(newReader.surface)

            newReader.setOnImageAvailableListener({ reader ->
                val image = try { reader.acquireLatestImage() } catch (e: Exception) { null }

                if (image != null) {
                    try {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * screenWidth

                        val paddedWidth = screenWidth + rowPadding / pixelStride
                        val paddedBitmap = Bitmap.createBitmap(
                            paddedWidth, screenHeight, Bitmap.Config.ARGB_8888
                        )
                        paddedBitmap.copyPixelsFromBuffer(buffer)
                        image.close()
                        reader.setOnImageAvailableListener(null, null)

                        val bitmap = if (paddedWidth != screenWidth) {
                            val cropped = Bitmap.createBitmap(
                                paddedBitmap, 0, 0, screenWidth, screenHeight
                            )
                            paddedBitmap.recycle()
                            cropped
                        } else {
                            paddedBitmap
                        }

                        showCropOverlay(bitmap)
                    } catch (e: Exception) {
                        try { image.close() } catch (_: Exception) {}
                        Toast.makeText(this, "Frame error: ${e.message}", Toast.LENGTH_LONG).show()
                        bubbleView?.visibility = View.VISIBLE
                    }
                }
            }, Handler(Looper.getMainLooper()))

        } catch (e: Exception) {
            Toast.makeText(this, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun showCropOverlay(bitmap: Bitmap) {
        cropView = CropOverlayView(
            this, bitmap,
            onCropped = { cropped ->
                cropView?.let {
                    if (it.isAttachedToWindow) windowManager.removeView(it)
                }
                openGeminiWeb(cropped)
            },
            onCancelled = {
                cropView?.let {
                    if (it.isAttachedToWindow) windowManager.removeView(it)
                }
                bubbleView?.visibility = View.VISIBLE
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        cropView?.let { windowManager.addView(it, params) }
    }

    private fun openGeminiWeb(bitmap: Bitmap) {
        try {
            val cacheDir = File(cacheDir, "crop")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            cacheDir.listFiles()?.forEach { it.delete() }

            val file = File(cacheDir, "crop_${System.currentTimeMillis()}.jpg")
            val fos = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            fos.close()

            val intent = Intent(this, GeminiWebActivity::class.java).apply {
                putExtra("crop_path", file.absolutePath)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)

            Handler(Looper.getMainLooper()).postDelayed({
                bubbleView?.visibility = View.VISIBLE
            }, 500)

        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka Gemini: ${e.message}", Toast.LENGTH_LONG).show()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (::windowManager.isInitialized) {
                cropView?.let {
                    if (it.isAttachedToWindow) windowManager.removeView(it)
                }
                bubbleView?.let {
                    if (it.isAttachedToWindow) windowManager.removeView(it)
                }
                expandedBubbleView?.let {
                    if (it.isAttachedToWindow) windowManager.removeView(it)
                }
                overlayView?.let {
                    if (it.isAttachedToWindow) windowManager.removeView(it)
                }
            }
        } catch (_: Exception) {}
        try {
            virtualDisplay?.release()
            currentImageReader?.close()
        } catch (_: Exception) {}
    }
}