package com.example.floatinggemini

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var mediaProjection: MediaProjection
    private lateinit var cropView: CropOverlayView
    private var bubbleView: View? = null
    private var miniBubbleView: View? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var currentImageReader: ImageReader? = null
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "SHOW_MIN_BUBBLE" -> {
                startForegroundNotification()
                showMiniBubble()
                return START_STICKY
            }
            "HIDE_MIN_BUBBLE" -> {
                hideMiniBubble()
                if (bubbleView == null) {
                    stopSelf()
                }
                return START_NOT_STICKY
            }
        }

        if (bubbleView != null && bubbleView!!.isAttachedToWindow) {
            bubbleView?.visibility = View.VISIBLE
            return START_NOT_STICKY
        }

        startForegroundNotification()

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra("data")
        }

        if (data == null) {
            // Service dipanggil tanpa data, mungkin cuma buat show/hide bubble
            showBubble()
            return START_STICKY
        }

        try {
            val projectionManager =
                getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            mediaProjection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    try {
                        virtualDisplay?.release()
                        currentImageReader?.close()
                    } catch (_: Exception) {}
                }
            }, Handler(Looper.getMainLooper()))

            val metrics = DisplayMetrics()
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                screenWidth = bounds.width()
                screenHeight = bounds.height()
                screenDensity = resources.configuration.densityDpi
            } else {
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(metrics)
                screenWidth = metrics.widthPixels
                screenHeight = metrics.heightPixels
                screenDensity = metrics.densityDpi
            }

            currentImageReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            )

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                currentImageReader!!.surface, null, null
            )

            showBubble()
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
            stopSelf()
        }

        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "floating_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Floating Service",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Floating Gemini Aktif")
            .setContentText("Tap bubble = crop, long-press = stop")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                1, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, notif)
        }
    }

    // Bubble utama (crop)
    private fun showBubble() {
        if (windowManager == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.layout_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var isDragging = false
            private var downTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        isDragging = false
                        downTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(bubbleView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val holdDuration = System.currentTimeMillis() - downTime
                        if (!isDragging) {
                            if (holdDuration > 800) {
                                Toast.makeText(
                                    this@FloatingService,
                                    "Floating Gemini dihentikan",
                                    Toast.LENGTH_SHORT
                                ).show()
                                hideMiniBubble()
                                stopSelf()
                            } else {
                                bubbleView?.visibility = View.GONE
                                Handler(Looper.getMainLooper()).postDelayed({
                                    captureScreen()
                                }, 250)
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(bubbleView, params)
    }

    // 🔥 Bubble mini (setelah minimize Gemini window)
    private fun showMiniBubble() {
        if (miniBubbleView != null && miniBubbleView!!.isAttachedToWindow) {
            miniBubbleView?.visibility = View.VISIBLE
            return
        }

        if (windowManager == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }

        val size = (56 * resources.displayMetrics.density).toInt()
        val iv = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            setBackgroundColor(0xFF3F51B5.toInt())
            setPadding(12, 12, 12, 12)
            setColorFilter(0xFFFFFFFF.toInt())
        }
        miniBubbleView = iv

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 900
        }

        iv.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var isDragging = false
            private var downTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        isDragging = false
                        downTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(miniBubbleView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val holdDuration = System.currentTimeMillis() - downTime
                        if (!isDragging) {
                            if (holdDuration > 800) {
                                // Long press = tutup mini bubble
                                hideMiniBubble()
                            } else {
                                // Tap = buka Gemini window lagi
                                openGeminiWindow()
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(miniBubbleView, params)
    }

    private fun hideMiniBubble() {
        miniBubbleView?.let {
            if (it.isAttachedToWindow) {
                try { windowManager.removeView(it) } catch (_: Exception) {}
            }
        }
        miniBubbleView = null
    }

    private fun openGeminiWindow() {
        try {
            val intent = Intent(this, GeminiWebActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka Gemini: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun captureScreen() {
        try {
            if (virtualDisplay == null) {
                bubbleView?.visibility = View.VISIBLE
                return
            }

            try {
                currentImageReader?.setOnImageAvailableListener(null, null)
                currentImageReader?.close()
            } catch (_: Exception) {}

            val newReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            )
            currentImageReader = newReader
            virtualDisplay?.setSurface(newReader.surface)

            newReader.setOnImageAvailableListener({ reader ->
                val image = try { reader.acquireLatestImage() } catch (e: Exception) { null }

                if (image != null) {
                    try {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * screenWidth

                        val paddedWidth = screenWidth + rowPadding / pixelStride
                        val paddedBitmap = Bitmap.createBitmap(
                            paddedWidth, screenHeight, Bitmap.Config.ARGB_8888
                        )
                        paddedBitmap.copyPixelsFromBuffer(buffer)
                        image.close()
                        reader.setOnImageAvailableListener(null, null)

                        val bitmap = if (paddedWidth != screenWidth) {
                            val cropped = Bitmap.createBitmap(
                                paddedBitmap, 0, 0, screenWidth, screenHeight
                            )
                            paddedBitmap.recycle()
                            cropped
                        } else {
                            paddedBitmap
                        }

                        showCropOverlay(bitmap)
                    } catch (e: Exception) {
                        try { image.close() } catch (_: Exception) {}
                        Toast.makeText(this, "Frame error: ${e.message}", Toast.LENGTH_LONG).show()
                        bubbleView?.visibility = View.VISIBLE
                    }
                }
            }, Handler(Looper.getMainLooper()))

        } catch (e: Exception) {
            Toast.makeText(this, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun showCropOverlay(bitmap: Bitmap) {
        cropView = CropOverlayView(
            this, bitmap,
            onCropped = { cropped ->
                windowManager.removeView(cropView)
                openGeminiWeb(cropped)
            },
            onCancelled = {
                windowManager.removeView(cropView)
                bubbleView?.visibility = View.VISIBLE
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(cropView, params)
    }

    private fun openGeminiWeb(bitmap: Bitmap) {
        try {
            val cacheDir = File(cacheDir, "crop")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            cacheDir.listFiles()?.forEach { it.delete() }

            val file = File(cacheDir, "crop_${System.currentTimeMillis()}.jpg")
            val fos = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            fos.close()

            val intent = Intent(this, GeminiWebActivity::class.java).apply {
                putExtra("crop_path", file.absolutePath)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)

            Handler(Looper.getMainLooper()).postDelayed({
                bubbleView?.visibility = View.VISIBLE
            }, 500)

        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka Gemini: ${e.message}", Toast.LENGTH_LONG).show()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cropView.isInitialized && cropView.isAttachedToWindow) {
            windowManager.removeView(cropView)
        }
        bubbleView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        hideMiniBubble()
        try {
            virtualDisplay?.release()
            currentImageReader?.close()
        } catch (_: Exception) {}
    }
}