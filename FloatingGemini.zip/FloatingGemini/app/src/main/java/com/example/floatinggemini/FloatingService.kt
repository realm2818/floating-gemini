package com.example.floatinggemini

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var mediaProjection: MediaProjection
    private var screenBitmap: Bitmap? = null
    private lateinit var cropView: CropOverlayView
    private var bubbleView: View? = null
    private var resultView: View? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var currentImageReader: ImageReader? = null
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 🔥 Cek kalau ini perintah STOP
        if (intent?.action == "STOP_SERVICE") {
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotification()

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra("data")
        }

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val projectionManager =
                getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            mediaProjection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    try {
                        virtualDisplay?.release()
                        currentImageReader?.close()
                    } catch (_: Exception) {}
                }
            }, Handler(Looper.getMainLooper()))

            val metrics = DisplayMetrics()
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                screenWidth = bounds.width()
                screenHeight = bounds.height()
                screenDensity = resources.configuration.densityDpi
            } else {
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(metrics)
                screenWidth = metrics.widthPixels
                screenHeight = metrics.heightPixels
                screenDensity = metrics.densityDpi
            }

            currentImageReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            )

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                currentImageReader!!.surface, null, null
            )

            showBubble()
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "floating_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Floating Service",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Floating Gemini Aktif")
            .setContentText("Tap bubble untuk mulai, long-press bubble untuk berhenti")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                1, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, notif)
        }
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.layout_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var isDragging = false
            private var downTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        isDragging = false
                        downTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(bubbleView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val holdDuration = System.currentTimeMillis() - downTime

                        if (!isDragging) {
                            if (holdDuration > 800) {
                                // 🔥 LONG PRESS: Stop service
                                Toast.makeText(
                                    this@FloatingService,
                                    "Floating Gemini dihentikan",
                                    Toast.LENGTH_SHORT
                                ).show()
                                stopSelf()
                            } else {
                                // TAP: screenshot
                                bubbleView?.visibility = View.GONE
                                Handler(Looper.getMainLooper()).postDelayed({
                                    captureScreen()
                                }, 250)
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(bubbleView, params)
    }

    private fun captureScreen() {
        try {
            if (virtualDisplay == null) {
                bubbleView?.visibility = View.VISIBLE
                return
            }

            try {
                currentImageReader?.setOnImageAvailableListener(null, null)
                currentImageReader?.close()
            } catch (_: Exception) {}

            val newReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
            )
            currentImageReader = newReader
            virtualDisplay?.setSurface(newReader.surface)

            newReader.setOnImageAvailableListener({ reader ->
                val image = try { reader.acquireLatestImage() } catch (e: Exception) { null }

                if (image != null) {
                    try {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * screenWidth

                        val paddedWidth = screenWidth + rowPadding / pixelStride
                        val paddedBitmap = Bitmap.createBitmap(
                            paddedWidth, screenHeight, Bitmap.Config.ARGB_8888
                        )
                        paddedBitmap.copyPixelsFromBuffer(buffer)
                        image.close()
                        reader.setOnImageAvailableListener(null, null)

                        val bitmap = if (paddedWidth != screenWidth) {
                            val cropped = Bitmap.createBitmap(
                                paddedBitmap, 0, 0, screenWidth, screenHeight
                            )
                            paddedBitmap.recycle()
                            cropped
                        } else {
                            paddedBitmap
                        }

                        screenBitmap = bitmap
                        showCropOverlay(bitmap)
                    } catch (e: Exception) {
                        try { image.close() } catch (_: Exception) {}
                        Toast.makeText(this, "Frame error: ${e.message}", Toast.LENGTH_LONG).show()
                        bubbleView?.visibility = View.VISIBLE
                    }
                }
            }, Handler(Looper.getMainLooper()))

        } catch (e: Exception) {
            Toast.makeText(this, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    // 🔥 Cuma satu layer: crop overlay dengan tombol di Canvas
    private fun showCropOverlay(bitmap: Bitmap) {
        cropView = CropOverlayView(
            this, bitmap,
            onCropped = { cropped ->
                windowManager.removeView(cropView)
                sendToGemini(cropped)
            },
            onCancelled = {
                windowManager.removeView(cropView)
                bubbleView?.visibility = View.VISIBLE
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(cropView, params)
    }

    private fun sendToGemini(bitmap: Bitmap) {
        bubbleView?.visibility = View.VISIBLE
        showResultWindow("Mengerjakan soal...")

        val prompt = """
            TUGAS: Kerjakan dan jawab pertanyaan/soal yang ada di gambar ini.
            
            ATURAN WAJIB:
            1. Langsung berikan JAWABAN yang benar, bukan analisis atau deskripsi gambar.
            2. Jika soal pilihan ganda, tulis jawabannya di awal dengan format:
               "Jawaban: [huruf]. [teks jawaban]"
            3. Setelah jawaban, baru berikan pembahasan singkat (maksimal 3 baris).
            4. Jika gambar tidak berisi soal/pertanyaan, baru jelaskan isi gambar.
            5. Jawab dalam bahasa Indonesia dengan teks biasa (plain text).
            6. DILARANG pakai simbol LaTeX/markdown seperti: \, ${'$'}, {, }, %, *, #, _, ^.
               Tulis "60 persen" bukan "60\%", tulis "x kuadrat" bukan "x^2".
        """.trimIndent()

        GeminiApiClient.analyzeImage(bitmap, prompt) { result ->
            Handler(Looper.getMainLooper()).post {
                updateResultWindow(result)
            }
        }
    }

    private fun showResultWindow(initialText: String) {
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        resultView = inflater.inflate(R.layout.layout_result, null)

        resultView?.findViewById<TextView>(R.id.tvResult)?.text = initialText

        resultView?.findViewById<Button>(R.id.btnCloseResult)?.setOnClickListener {
            resultView?.let {
                if (it.isAttachedToWindow) windowManager.removeView(it)
            }
            bubbleView?.visibility = View.VISIBLE
        }

        val params = WindowManager.LayoutParams(
            800,
            1000,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            flags = flags or WindowManager.LayoutParams.FLAG_SECURE
        }

        resultView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(resultView, params)
                        return true
                    }
                }
                return false
            }
        })

        resultView?.findViewById<View>(R.id.resizeHandle)?.setOnTouchListener(
            object : View.OnTouchListener {
                private var initialW = 0
                private var initialH = 0
                private var touchX = 0f
                private var touchY = 0f

                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialW = params.width
                            initialH = params.height
                            touchX = event.rawX
                            touchY = event.rawY
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = event.rawX - touchX
                            val dy = event.rawY - touchY
                            params.width = (initialW + dx).toInt().coerceAtLeast(500)
                            params.height = (initialH + dy).toInt().coerceAtLeast(500)
                            windowManager.updateViewLayout(resultView, params)
                            return true
                        }
                    }
                    return false
                }
            })

        windowManager.addView(resultView, params)
    }

    private fun updateResultWindow(text: String) {
        resultView?.findViewById<TextView>(R.id.tvResult)?.text = text
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cropView.isInitialized && cropView.isAttachedToWindow) {
            windowManager.removeView(cropView)
        }
        bubbleView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        resultView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        try {
            virtualDisplay?.release()
            currentImageReader?.close()
        } catch (_: Exception) {}
    }
}