package com.example.floatinggemini

import android.graphics.Bitmap
import android.util.Base64
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException

object GeminiApiClient {

    // 🔑 API Key kamu
    private const val API_KEY = "AQ.Ab8RN6K9ULpObMtqMDSrJg4Kycrro_6JgkCn9-uctvG4qzcN4A"

    private const val URL =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-lite-latest:generateContent"

    fun analyzeImage(bitmap: Bitmap, prompt: String, callback: (String) -> Unit) {
        // 1. Convert Bitmap ke Base64
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

        // 2. Susun JSON Payload
        val jsonPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                        put(JSONObject().put("inline_data", JSONObject().apply {
                            put("mime_type", "image/jpeg")
                            put("data", base64Image)
                        }))
                    })
                })
            })
        }

        // 3. 🔥 AUTO-DETECT FORMAT KEY
        val requestBuilder = Request.Builder()
            .url(URL)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))

        if (API_KEY.startsWith("AIza")) {
            // API Key lama
            requestBuilder.addHeader("x-goog-api-key", API_KEY)
        } else {
            // OAuth Token baru (format AQ.)
            requestBuilder.addHeader("Authorization", "Bearer $API_KEY")
        }

        val request = requestBuilder.build()

        // 4. Kirim Request
        val client = OkHttpClient()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Gagal koneksi: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: "Empty response"
                try {
                    val jsonResponse = JSONObject(body)
                    val text = jsonResponse
                        .getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    callback(text)
                } catch (e: Exception) {
                    callback("Error parsing: $body")
                }
            }
        })
    }
}