package com.example.floatinggemini

import android.graphics.Bitmap
import android.util.Base64
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException

object GeminiApiClient {

    // 🔑 Auth Key format AQ. (dari AI Studio)
    private const val API_KEY = "AQ.Ab8RN6K9ULpObMtqMDSrJg4Kycrro_6JgkCn9-uctvG4qzcN4A"

    // 📦 Project ID dari Gemini Project
    private const val PROJECT_ID = "gen-lang-client-0015731084"

    // 🌍 Region (bisa us-central1, asia-southeast1, atau global)
    private const val REGION = "us-central1"

    // 🤖 Model — pakai gemini-2.0-flash (Flash-Lite juga bisa)
    private const val MODEL = "gemini-2.0-flash"

    private val URL =
        "https://$REGION-aiplatform.googleapis.com/v1/projects/$PROJECT_ID/locations/$REGION/publishers/google/models/$MODEL:generateContent"

    fun analyzeImage(bitmap: Bitmap, prompt: String, callback: (String) -> Unit) {
        // 1. Convert Bitmap ke Base64
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

        // 2. Susun JSON Payload (format Vertex AI)
        val jsonPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                        put(JSONObject().put("inline_data", JSONObject().apply {
                            put("mime_type", "image/jpeg")
                            put("data", base64Image)
                        }))
                    })
                })
            })
        }

        // 3. Kirim Request dengan Bearer Token
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(URL)
            .addHeader("Authorization", "Bearer $API_KEY")
            .addHeader("Content-Type", "application/json")
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Gagal koneksi: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: "Empty response"
                try {
                    val jsonResponse = JSONObject(body)
                    val text = jsonResponse
                        .getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    callback(text)
                } catch (e: Exception) {
                    callback("Error parsing: $body")
                }
            }
        })
    }
}