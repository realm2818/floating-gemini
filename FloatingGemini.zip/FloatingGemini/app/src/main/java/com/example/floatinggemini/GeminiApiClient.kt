package com.example.floatinggemini

import android.graphics.Bitmap
import android.util.Base64
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException

object GeminiApiClient {

    // ⚠️ GANTI DENGAN API KEY KAMU (format AQ.Ab8... atau AIzaSy...)
    private const val API_KEY = "AQ.Ab8RN6L3BTjHiKQDkLnTnBn57YV8txcJxCRSQS60zPdos-sM4g"

    // 🔥 UBAH: URL tanpa ?key= (key dikirim lewat header)
    private const val URL =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-lite-latest:generateContent"

    fun analyzeImage(bitmap: Bitmap, prompt: String, callback: (String) -> Unit) {
        // 1. Convert Bitmap ke Base64
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

        // 2. Susun JSON Payload
        val jsonPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                        put(JSONObject().put("inline_data", JSONObject().apply {
                            put("mime_type", "image/jpeg")
                            put("data", base64Image)
                        }))
                    })
                })
            })
        }

        // 3. Kirim Request ke Gemini
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(URL)
            .addHeader("x-goog-api-key", API_KEY)   // 🔥 KEY DIKIRIM LEWAT HEADER
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Gagal koneksi: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: "Empty response"
                try {
                    val jsonResponse = JSONObject(body)
                    val text = jsonResponse
                        .getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    callback(text)
                } catch (e: Exception) {
                    callback("Error parsing: $body")
                }
            }
        })
    }
}