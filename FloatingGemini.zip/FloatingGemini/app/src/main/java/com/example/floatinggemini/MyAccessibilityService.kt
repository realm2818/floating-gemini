package com.example.floatinggemini

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.hardware.HardwareBuffer
import android.os.Build
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi
import java.util.concurrent.Executors

/**
 * AccessibilityService buat screenshot tanpa MediaProjection.
 * Jalan barengan sama aplikasi recorder lain.
 */
class MyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MyAccessibility"

        // 🔥 Instance global biar bisa dipanggil dari FloatingService
        @Volatile
        var instance: MyAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "✅ AccessibilityService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Nggak butuh event, cukup buat screenshot aja
    }

    override fun onInterrupt() {
        // Nggak butuh
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.d(TAG, "❌ AccessibilityService disconnected")
    }

    // ============================
    // 🔥 SCREENSHOT VIA ACCESSIBILITY
    // ============================
    @RequiresApi(Build.VERSION_CODES.R)
    fun takeScreenshot(onResult: (Bitmap?) -> Unit) {
        try {
            val executor = Executors.newSingleThreadExecutor()

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hardwareBuffer: HardwareBuffer = screenshot.hardwareBuffer
                            val bitmap = Bitmap.wrapHardwareBuffer(
                                hardwareBuffer,
                                screenshot.colorSpace
                            )

                            // Copy bitmap biar aman dipakai di thread lain
                            val copy = bitmap?.copy(Bitmap.Config.ARGB_8888, false)

                            // Close hardware buffer biar nggak leak
                            hardwareBuffer.close()

                            onResult(copy)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error convert bitmap: ${e.message}")
                            onResult(null)
                        } finally {
                            executor.shutdown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        Log.e(TAG, "Screenshot failed, code: $errorCode")
                        onResult(null)
                        executor.shutdown()
                    }
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "takeScreenshot exception: ${e.message}")
            onResult(null)
        }
    }
}