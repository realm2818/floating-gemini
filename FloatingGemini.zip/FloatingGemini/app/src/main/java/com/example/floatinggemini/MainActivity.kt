package com.example.floatinggemini

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_OVERLAY = 1001
    private val REQ_MEDIA_PROJECTION = 1002
    private val REQ_NOTIFICATION = 1003

    private lateinit var seekSize: SeekBar
    private lateinit var seekOpacity: SeekBar
    private lateinit var tvSizeValue: TextView
    private lateinit var tvOpacityValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        seekSize = findViewById(R.id.seekSize)
        seekOpacity = findViewById(R.id.seekOpacity)
        tvSizeValue = findViewById(R.id.tvSizeValue)
        tvOpacityValue = findViewById(R.id.tvOpacityValue)

        val prefs = getSharedPreferences("floating_pref", MODE_PRIVATE)

        // Load setting yang tersimpan
        val savedSize = prefs.getInt("bubble_size", 60)
        val savedOpacity = prefs.getInt("bubble_opacity", 100)

        seekSize.progress = savedSize - 40   // range 40-80, jadi progress 0-40
        seekOpacity.progress = savedOpacity

        tvSizeValue.text = "$savedSize dp"
        tvOpacityValue.text = "$savedOpacity%"

        seekSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = progress + 40
                tvSizeValue.text = "$size dp"
                prefs.edit().putInt("bubble_size", size).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                tvOpacityValue.text = "$progress%"
                prefs.edit().putInt("bubble_opacity", progress).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val autoPrompt = findViewById<RadioButton>(R.id.radioAutoPrompt).isChecked
            prefs.edit()
                .putBoolean("auto_prompt", autoPrompt)
                .apply()

            if (checkOverlayPermission()) {
                askNotificationAndStart()
            }
        }
    }

    private fun askNotificationAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    REQ_NOTIFICATION
                )
                return
            }
        }
        requestMediaProjection()
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(this)
        ) {
            startActivityForResult(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ),
                REQ_OVERLAY
            )
            false
        } else true
    }

    private fun requestMediaProjection() {
        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(
            projectionManager.createScreenCaptureIntent(),
            REQ_MEDIA_PROJECTION
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATION) {
            requestMediaProjection()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            askNotificationAndStart()
        } else if (requestCode == REQ_MEDIA_PROJECTION &&
            resultCode == Activity.RESULT_OK && data != null
        ) {
            val intent = Intent(this, FloatingService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Toast.makeText(this, "Bubble aktif — tap untuk opsi", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}