package com.example.floatingapp

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_OVERLAY = 1001
    private val REQ_NOTIFICATION = 1003

    private lateinit var seekSize: SeekBar
    private lateinit var seekOpacity: SeekBar
    private lateinit var tvSizeValue: TextView
    private lateinit var tvOpacityValue: TextView
    private lateinit var tvAksesibilitas: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        seekSize = findViewById(R.id.seekSize)
        seekOpacity = findViewById(R.id.seekOpacity)
        tvSizeValue = findViewById(R.id.tvSizeValue)
        tvOpacityValue = findViewById(R.id.tvOpacityValue)
        tvAksesibilitas = findViewById(R.id.tvAksesibilitas)

        val prefs = getSharedPreferences("floating_pref", MODE_PRIVATE)

        // Load setting yang tersimpan
        val savedSize = prefs.getInt("bubble_size", 60)
        val savedOpacity = prefs.getInt("bubble_opacity", 100)

        seekSize.progress = savedSize - 40   // range 40-80, jadi progress 0-40
        seekOpacity.progress = savedOpacity

        tvSizeValue.text = "$savedSize dp"
        tvOpacityValue.text = "$savedOpacity%"

        seekSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = progress + 40
                tvSizeValue.text = "$size dp"
                prefs.edit().putInt("bubble_size", size).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                tvOpacityValue.text = "$progress%"
                prefs.edit().putInt("bubble_opacity", progress).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        tvAksesibilitas.setOnClickListener { openAccessibilitySettings() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val autoPrompt = findViewById<RadioButton>(R.id.radioAutoPrompt).isChecked
            prefs.edit()
                .putBoolean("auto_prompt", autoPrompt)
                .apply()

            if (checkOverlayPermission()) {
                askNotificationAndStart()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Teks peringatan hilang otomatis kalau aksesibilitas sudah aktif
        tvAksesibilitas.visibility =
            if (isAccessibilityEnabled()) View.GONE else View.VISIBLE
    }

    private fun isAccessibilityEnabled(): Boolean {
        if (ScreenshotAccessibilityService.instance != null) return true
        val component = ComponentName(this, ScreenshotAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(component.flattenToString(), ignoreCase = true) ||
                it.equals(component.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka pengaturan: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askNotificationAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    REQ_NOTIFICATION
                )
                return
            }
        }
        startFloating()
    }

    private fun checkOverlayPermission(): Boolean {
        return if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ),
                REQ_OVERLAY
            )
            false
        } else true
    }

    private fun startFloating() {
        startForegroundService(Intent(this, FloatingService::class.java))

        if (isAccessibilityEnabled()) {
            Toast.makeText(this, "Bubble aktif — tap untuk opsi", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            // Tetap di halaman ini supaya petunjuk aksesibilitas terlihat
            Toast.makeText(
                this,
                "Bubble aktif. Aktifkan aksesibilitas supaya Scan bisa dipakai",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATION) {
            startFloating()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            askNotificationAndStart()
        }
    }
}
