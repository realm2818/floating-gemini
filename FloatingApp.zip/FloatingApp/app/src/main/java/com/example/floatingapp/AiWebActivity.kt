package com.example.floatingapp

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class AiWebActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var tvStatus: TextView
    private lateinit var headerBar: LinearLayout
    private lateinit var bottomHandle: View
    private lateinit var resizeHandle: View

    private var cropFile: File? = null
    private var currentProvider: AiProvider? = null
    private var autoPrompt = false
    private var injectedOnce = false
    private var lastW = 0
    private var lastH = 0
    private var lastX = 0
    private var lastY = 0
    private var hasPosition = false

    private lateinit var prefs: SharedPreferences

    companion object {
        private const val PREF_NAME = "ai_web_pref"
        private const val KEY_WIDTH = "window_width"
        private const val KEY_HEIGHT = "window_height"
        private const val KEY_X = "window_x"
        private const val KEY_Y = "window_y"
        private const val MIN_W = 500
        private const val MIN_H = 700
        private const val SWIPE_UP_THRESHOLD = 120f

        var instance: AiWebActivity? = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_web)

        // Hapus judul "Floating App" di atas
        supportActionBar?.hide()
        actionBar?.hide()

        instance = this
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE)

        webView = findViewById(R.id.webView)
        tvStatus = findViewById(R.id.tvStatus)
        headerBar = findViewById(R.id.headerBar)
        bottomHandle = findViewById(R.id.bottomHandle)
        resizeHandle = findViewById(R.id.resizeHandle)

        window?.setBackgroundDrawableResource(android.R.color.transparent)

        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels

        // 🔥 RESTORE UKURAN
        lastW = prefs.getInt(KEY_WIDTH, (screenW * 0.92).toInt())
        lastH = prefs.getInt(KEY_HEIGHT, (screenH * 0.80).toInt())
        window?.setLayout(lastW, lastH)

        // 🔥 RESTORE POSISI
        hasPosition = prefs.contains(KEY_X)
        if (hasPosition) {
            lastX = prefs.getInt(KEY_X, 0)
            lastY = prefs.getInt(KEY_Y, 0)
            val params = window?.attributes
            if (params != null) {
                params.x = lastX
                params.y = lastY
                window?.attributes = params
            }
        }

        setFinishOnTouchOutside(false)

        val cropPath = intent.getStringExtra("crop_path")
        if (cropPath != null) cropFile = File(cropPath)

        autoPrompt = getSharedPreferences("floating_pref", MODE_PRIVATE)
            .getBoolean("auto_prompt", false)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false

            // Samarkan UA WebView supaya lebih mirip Chrome biasa
            // (bantu login & verifikasi di beberapa situs AI)
            userAgentString = userAgentString
                .replace("; wv", "")
                .replace(Regex("Version/\\d+\\.\\d+\\s?"), "")
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (cropFile != null && cropFile!!.exists()) {
                    try {
                        val uri = FileProvider.getUriForFile(
                            this@AiWebActivity,
                            "$packageName.fileprovider",
                            cropFile!!
                        )
                        filePathCallback?.onReceiveValue(arrayOf(uri))
                        tvStatus.text = "✅ Gambar keisi! Tap kirim ▶"
                    } catch (e: Exception) {
                        Log.e("AiWeb", "FileProvider error: ${e.message}")
                        filePathCallback?.onReceiveValue(null)
                    }
                    return true
                }
                return false
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                tvStatus.text = "Tap 📎 di ${currentProvider?.label ?: "AI"} untuk kirim gambar"

                if (autoPrompt && !injectedOnce) {
                    injectedOnce = true
                    Handler(Looper.getMainLooper()).postDelayed({ injectPrompt() }, 1500)
                }
            }
        }

        loadSelectedProvider()

        findViewById<Button>(R.id.btnClose).setOnClickListener {
            saveAll()
            showMainBubble()
            finish()
            instance = null
        }

        findViewById<Button>(R.id.btnMinimize).setOnClickListener {
            minimizeWindow()
        }

        setupDrag()
        setupResize()
        setupBottomSwipe()
    }

    // Muat AI yang dipilih di menu bubble. Return true kalau halaman dimuat ulang.
    private fun loadSelectedProvider(): Boolean {
        val provider = AiProvider.fromName(
            getSharedPreferences("floating_pref", MODE_PRIVATE)
                .getString(AiProvider.PREF_KEY, null)
        )
        if (provider == currentProvider && webView.url != null) return false

        currentProvider = provider
        injectedOnce = false
        tvStatus.text = "Memuat ${provider.label}..."
        webView.loadUrl(provider.url)
        return true
    }

    private fun setupBottomSwipe() {
        bottomHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = event.rawY - startY
                        if (dy < -SWIPE_UP_THRESHOLD) {
                            minimizeWindow()
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun minimizeWindow() {
        saveAll()
        showMainBubble()
        moveTaskToBack(true)
    }

    private fun showMainBubble() {
        try {
            val svcIntent = Intent(this, FloatingService::class.java).apply {
                action = "SHOW_MAIN_BUBBLE"
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
        } catch (e: Exception) {
            Log.e("AiWeb", "Failed to show bubble: ${e.message}")
        }
    }

    // 🔥 FIX: Auto-prompt muncul LAGI saat crop baru
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        autoPrompt = getSharedPreferences("floating_pref", MODE_PRIVATE)
            .getBoolean("auto_prompt", false)

        // Kalau AI yang dipilih berubah, halaman dimuat ulang
        val providerChanged = loadSelectedProvider()

        val newCropPath = intent.getStringExtra("crop_path")
        if (newCropPath != null) {
            cropFile = File(newCropPath)
            tvStatus.text = "Gambar baru siap — tap 📎 untuk kirim"

            // Reset flag & inject prompt baru
            // (kalau halaman baru dimuat, onPageFinished yang inject)
            if (autoPrompt && !providerChanged) {
                injectedOnce = false
                Handler(Looper.getMainLooper()).postDelayed({
                    injectPrompt()
                }, 800)
            }
        }
    }

    private fun setupDrag() {
        headerBar.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = window?.attributes ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        window?.attributes = params
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        // 🔥 Simpan posisi setelah drag selesai
                        saveAll()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun setupResize() {
        resizeHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startW = 0
            private var startH = 0
            private var startX = 0f
            private var startY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        val params = window?.attributes ?: return false
                        startW = params.width
                        startH = params.height
                        startX = event.rawX
                        startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lastW = (startW + (event.rawX - startX)).toInt().coerceAtLeast(MIN_W)
                        lastH = (startH + (event.rawY - startY)).toInt().coerceAtLeast(MIN_H)
                        window?.setLayout(lastW, lastH)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveAll()
                        return true
                    }
                }
                return false
            }
        })
    }

    // 🔥 Save ukuran + posisi
    private fun saveAll() {
        val params = window?.attributes
        prefs.edit()
            .putInt(KEY_WIDTH, lastW)
            .putInt(KEY_HEIGHT, lastH)
            .putInt(KEY_X, params?.x ?: lastX)
            .putInt(KEY_Y, params?.y ?: lastY)
            .apply()
    }

    private fun injectPrompt() {
        val js = """
            (function() {
                try {
                    var prompt = 'Jawab atau kerjakan soal ini';
                    var marker = 'Jawab atau kerjakan';
                    var selectors = [
                        'rich-textarea [contenteditable="true"]',
                        '.ql-editor',
                        'div[contenteditable="true"]',
                        'textarea'
                    ];
                    var editor = null;
                    for (var i = 0; i < selectors.length && !editor; i++) {
                        var list = document.querySelectorAll(selectors[i]);
                        for (var j = 0; j < list.length; j++) {
                            if (list[j].offsetWidth > 0 || list[j].offsetHeight > 0) {
                                editor = list[j];
                                break;
                            }
                        }
                    }
                    if (!editor) return 'notfound';

                    editor.focus();

                    // textarea / input (React): pakai native value setter
                    if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
                        var proto = editor.tagName === 'INPUT'
                            ? window.HTMLInputElement.prototype
                            : window.HTMLTextAreaElement.prototype;
                        var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
                        var cur = editor.value || '';
                        var next = cur.indexOf(marker) !== -1 ? prompt : (cur ? cur + ' ' + prompt : prompt);
                        setter.call(editor, next);
                        editor.dispatchEvent(new Event('input', { bubbles: true }));
                        return 'ok-native';
                    }

                    // contenteditable (Gemini, ChatGPT, Claude)
                    var currentText = editor.innerText || '';
                    if (currentText.indexOf(marker) !== -1) {
                        editor.innerText = '';
                        editor.dispatchEvent(new Event('input', { bubbles: true }));
                    }
                    editor.click();
                    try {
                        document.execCommand('insertText', false, prompt);
                        return 'ok-exec';
                    } catch (e) {}

                    editor.innerText = prompt;
                    editor.dispatchEvent(new Event('input', { bubbles: true }));
                    editor.dispatchEvent(new Event('change', { bubbles: true }));
                    return 'ok-inner';
                } catch (e) {
                    return 'error: ' + e.message;
                }
            })();
        """.trimIndent()

        webView.evaluateJavascript(js) { result ->
            Log.d("AiInject", "Result: " + result)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            saveAll()
            showMainBubble()
            @Suppress("DEPRECATION")
            super.onBackPressed()
            instance = null
        }
    }

    override fun onPause() {
        super.onPause()
        saveAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }
}