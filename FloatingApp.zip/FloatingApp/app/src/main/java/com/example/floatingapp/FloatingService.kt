package com.example.floatingapp

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: SharedPreferences
    private var cropView: CropOverlayView? = null
    private var bubbleView: View? = null
    private var expandedBubbleView: View? = null
    private var overlayView: View? = null
    private var pickerView: View? = null
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("floating_pref", MODE_PRIVATE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::windowManager.isInitialized) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }

        startForegroundNotification()

        if (intent?.action == "HIDE_MIN_BUBBLE") {
            bubbleView?.visibility = View.GONE
            return START_STICKY
        }

        val existing = bubbleView
        if (existing == null) {
            try {
                showBubble()
            } catch (e: Exception) {
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
            }
        } else if (existing.isAttachedToWindow) {
            existing.visibility = View.VISIBLE
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "floating_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Floating Service",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Floating App Aktif")
            .setContentText("Tap bubble = opsi, long-press = stop")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                1, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1, notif)
        }
    }

    // ── Overlay helpers: routing lewat AccessibilityService kalau aktif ──────
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addOverlayView(view: View, params: WindowManager.LayoutParams) {
        val svc = ScreenshotAccessibilityService.instance
        if (svc != null) {
            svc.addOverlay(view, params)   // TYPE_ACCESSIBILITY_OVERLAY, tembus SIUS
        } else {
            params.type = overlayType()
            windowManager.addView(view, params)
        }
    }

    private fun removeOverlayView(view: View) {
        val svc = ScreenshotAccessibilityService.instance
        if (svc != null) {
            svc.removeOverlay(view)
        } else {
            try { windowManager.removeView(view) } catch (_: Exception) {}
        }
    }

    private fun updateOverlayView(view: View, params: WindowManager.LayoutParams) {
        val svc = ScreenshotAccessibilityService.instance
        if (svc != null) {
            svc.updateOverlay(view, params)
        } else {
            try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
        }
    }
    // ─────────────────────────────────────────────────────────────────────────

    // ============================
    // BUBBLE UTAMA
    // ============================
    private fun showBubble() {
        if (!::windowManager.isInitialized) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }

        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.layout_bubble, null)

        val sizeDp = prefs.getInt("bubble_size", 60)
        val opacityPercent = prefs.getInt("bubble_opacity", 100)
        val sizePx = (sizeDp * resources.displayMetrics.density).toInt()

        val savedX = prefs.getInt("bubble_x", 100)
        val savedY = prefs.getInt("bubble_y", 300)

        val params = WindowManager.LayoutParams(
            sizePx, sizePx,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        bubbleView?.alpha = opacityPercent / 100f

        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var isDragging = false
            private var downTime = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        isDragging = false
                        downTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        updateOverlayView(bubbleView!!, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        prefs.edit()
                            .putInt("bubble_x", params.x)
                            .putInt("bubble_y", params.y)
                            .apply()

                        val holdDuration = System.currentTimeMillis() - downTime
                        if (!isDragging) {
                            if (holdDuration > 800) {
                                Toast.makeText(
                                    this@FloatingService,
                                    "Floating App dihentikan",
                                    Toast.LENGTH_SHORT
                                ).show()
                                stopSelf()
                            } else {
                                expandBubble(params.x, params.y)
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })

        addOverlayView(bubbleView!!, params)
    }

    // ============================
    // BUBBLE MEKAR (3 tombol: Scan, Web & AI)
    // ============================
    private fun expandBubble(bubbleX: Int, bubbleY: Int) {
        if (isExpanded) return
        isExpanded = true

        bubbleView?.visibility = View.GONE

        overlayView = View(this).apply {
            setBackgroundColor(0x33000000.toInt())
            isClickable = true
            setOnClickListener { collapseBubble() }
        }
        val overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        addOverlayView(overlayView!!, overlayParams)

        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        expandedBubbleView = inflater.inflate(R.layout.layout_bubble_expanded, null)

        val expandParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleX
            y = bubbleY
        }
        addOverlayView(expandedBubbleView!!, expandParams)

        expandedBubbleView?.findViewById<TextView>(R.id.btnScanBubble)?.setOnClickListener {
            collapseBubble()
            bubbleView?.visibility = View.GONE
            Handler(Looper.getMainLooper()).postDelayed({
                captureScreen()
            }, 250)
        }

        expandedBubbleView?.findViewById<TextView>(R.id.btnWebBubble)?.setOnClickListener {
            collapseBubble()
            openAiWindow()
        }

        expandedBubbleView?.findViewById<TextView>(R.id.btnAiBubble)?.setOnClickListener {
            showAiPicker(bubbleX, bubbleY)
        }
    }

    // ============================
    // PILIH AI
    // ============================
    private fun showAiPicker(bubbleX: Int, bubbleY: Int) {
        if (pickerView != null) return

        expandedBubbleView?.visibility = View.GONE

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val selected = AiProvider.fromName(prefs.getString(AiProvider.PREF_KEY, null))

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                setColor(0xEE000000.toInt())
                cornerRadius = dp(12).toFloat()
            }
            elevation = dp(8).toFloat()
        }

        container.addView(TextView(this).apply {
            text = "Pilih AI"
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        })

        AiProvider.values().forEach { provider ->
            val isSelected = provider == selected
            container.addView(TextView(this).apply {
                text = if (isSelected) "✓  ${provider.label}" else provider.label
                setTextColor(Color.WHITE)
                textSize = 15f
                setTypeface(typeface, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
                setPadding(dp(14), dp(11), dp(14), dp(11))
                background = GradientDrawable().apply {
                    setColor(if (isSelected) 0xFF3F51B5.toInt() else Color.TRANSPARENT)
                    cornerRadius = dp(8).toFloat()
                }
                setOnClickListener {
                    prefs.edit().putString(AiProvider.PREF_KEY, provider.name).apply()
                    Toast.makeText(
                        this@FloatingService, "AI: ${provider.label}", Toast.LENGTH_SHORT
                    ).show()
                    collapseBubble()
                }
            })
        }

        val widthPx = dp(190)
        val maxX = (resources.displayMetrics.widthPixels - widthPx).coerceAtLeast(0)
        val maxY = (resources.displayMetrics.heightPixels - dp(320)).coerceAtLeast(0)

        val params = WindowManager.LayoutParams(
            widthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleX.coerceIn(0, maxX)
            y = bubbleY.coerceIn(0, maxY)
        }

        pickerView = container
        addOverlayView(container, params)
    }

    private fun collapseBubble() {
        if (!isExpanded) return
        isExpanded = false

        expandedBubbleView?.let { removeOverlayView(it) }
        expandedBubbleView = null

        pickerView?.let { removeOverlayView(it) }
        pickerView = null

        overlayView?.let { removeOverlayView(it) }
        overlayView = null

        bubbleView?.visibility = View.VISIBLE
    }

    // ============================
    // BUKA WEB AI
    // ============================
    private fun openAiWindow() {
        try {
            val intent = Intent(this, AiWebActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka AI: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ============================
    // SCREENSHOT & CROP
    // ============================
    private fun captureScreen() {
        val service = ScreenshotAccessibilityService.instance
        if (service == null) {
            Toast.makeText(
                this, "Aktifkan aksesibilitas Floating App dulu", Toast.LENGTH_LONG
            ).show()
            try {
                startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
            bubbleView?.visibility = View.VISIBLE
            return
        }

        service.capture { bitmap ->
            if (bitmap != null) {
                showCropOverlay(bitmap)
            } else {
                Toast.makeText(
                    this, "Gagal ambil screenshot, coba lagi", Toast.LENGTH_SHORT
                ).show()
                bubbleView?.visibility = View.VISIBLE
            }
        }
    }

    private fun showCropOverlay(bitmap: Bitmap) {
        cropView = CropOverlayView(
            this, bitmap,
            onCropped = { cropped ->
                cropView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
                openAiWeb(cropped)
            },
            onCancelled = {
                cropView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
                bubbleView?.visibility = View.VISIBLE
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        cropView?.let { addOverlayView(it, params) }
    }

    private fun openAiWeb(bitmap: Bitmap) {
        try {
            val cacheDir = File(cacheDir, "crop")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            cacheDir.listFiles()?.forEach { it.delete() }

            val file = File(cacheDir, "crop_${System.currentTimeMillis()}.jpg")
            val fos = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            fos.close()

            val intent = Intent(this, AiWebActivity::class.java).apply {
                putExtra("crop_path", file.absolutePath)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)

            Handler(Looper.getMainLooper()).postDelayed({
                bubbleView?.visibility = View.VISIBLE
            }, 500)

        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka AI: ${e.message}", Toast.LENGTH_LONG).show()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            cropView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
            bubbleView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
            expandedBubbleView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
            overlayView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
            pickerView?.let { if (it.isAttachedToWindow) removeOverlayView(it) }
        } catch (_: Exception) {}
    }
}
