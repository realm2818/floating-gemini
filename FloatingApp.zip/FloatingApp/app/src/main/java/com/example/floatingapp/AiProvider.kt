package com.example.floatingapp

enum class AiProvider(val label: String, val url: String) {
    GEMINI("Gemini", "https://gemini.google.com/app"),
    CHATGPT("ChatGPT", "https://chatgpt.com/"),
    DEEPSEEK("DeepSeek", "https://chat.deepseek.com/"),
    CLAUDE("Claude", "https://claude.ai/new"),
    GROK("Grok", "https://grok.com/");

    companion object {
        const val PREF_KEY = "ai_provider"

        fun fromName(name: String?): AiProvider =
            values().firstOrNull { it.name == name } ?: GEMINI
    }
}
