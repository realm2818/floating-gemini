package com.example.floatingapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.view.Display
import android.view.accessibility.AccessibilityEvent

/**
 * Dipakai hanya untuk takeScreenshot() saat tombol Scan ditekan.
 * Tidak membaca isi layar dan tidak merekam layar.
 */
class ScreenshotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenshotAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Ambil satu screenshot. Callback dipanggil di main thread; null kalau gagal. */
    fun capture(onResult: (Bitmap?) -> Unit) {
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var out: Bitmap? = null
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                result.hardwareBuffer, result.colorSpace
                            )
                            if (hw != null) {
                                out = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                            }
                        } catch (_: Exception) {
                        } finally {
                            try { result.hardwareBuffer.close() } catch (_: Exception) {}
                        }
                        onResult(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        onResult(null)
                    }
                }
            )
        } catch (_: Exception) {
            onResult(null)
        }
    }
}
