package com.example.floatingapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Dipakai untuk takeScreenshot() dan sebagai host TYPE_ACCESSIBILITY_OVERLAY
 * agar floating bisa muncul di atas app yang memblock TYPE_APPLICATION_OVERLAY.
 */
class ScreenshotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenshotAccessibilityService? = null
    }

    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    // ── Overlay bridge ──────────────────────────────────────────────
    fun addOverlay(view: View, params: WindowManager.LayoutParams) {
        params.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        wm.addView(view, params)
    }

    fun removeOverlay(view: View) {
        try { wm.removeView(view) } catch (_: Exception) {}
    }

    fun updateOverlay(view: View, params: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
    }
    // ────────────────────────────────────────────────────────────────

    /** Ambil satu screenshot. Callback dipanggil di main thread; null kalau gagal. */
    fun capture(onResult: (Bitmap?) -> Unit) {
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var out: Bitmap? = null
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                result.hardwareBuffer, result.colorSpace
                            )
                            if (hw != null) {
                                out = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                            }
                        } catch (_: Exception) {
                        } finally {
                            try { result.hardwareBuffer.close() } catch (_: Exception) {}
                        }
                        onResult(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        onResult(null)
                    }
                }
            )
        } catch (_: Exception) {
            onResult(null)
        }
    }
}
